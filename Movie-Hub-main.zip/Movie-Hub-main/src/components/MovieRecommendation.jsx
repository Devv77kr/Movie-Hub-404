import React from 'react'

function MovieRecommendation() {
  return (
    <div className='text-white'>AI Recommendation will be available soon</div>
  )
}

export default MovieRecommendation