export const API_KEY = import.meta.env.VITE_TMDB_API_KEY || ""
export const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || ""